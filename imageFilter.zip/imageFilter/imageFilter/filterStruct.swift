//
//  filterStruct.swift
//  imageFilter
//
//  Created by Apple on 12/24/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

struct Filter {
    let filterName: String
    var filterEffectValue: Any?
    var filterEffectName: String?
    
    init(filterName: String,filterEffectValue: Any?,filterEffectName: String?) {
        self.filterName = filterName
        self.filterEffectValue = filterEffectValue
        self.filterEffectName = filterEffectName
    }
}
