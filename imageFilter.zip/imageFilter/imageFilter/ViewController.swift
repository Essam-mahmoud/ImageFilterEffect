//
//  ViewController.swift
//  imageFilter
//
//  Created by Apple on 12/24/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    private var originalImage: UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        originalImage = imageView.image
        // Do any additional setup after loading the view.
    }
    
    private func applyFilterTo(image: UIImage,filterEffect: Filter) -> UIImage{
        guard let cgImage = image.cgImage, let openGlContext = EAGLContext(api: .openGLES3) else {return UIImage()}
        let context = CIContext(eaglContext: openGlContext)
        let ciImage = CIImage(cgImage: cgImage)
        let filter = CIFilter(name: filterEffect.filterName)
        filter?.setValue(ciImage, forKey: kCIInputImageKey)
        
        if let filterEffectValue = filterEffect.filterEffectValue, let filterEffectName = filterEffect.filterEffectName{
            filter?.setValue(filterEffectValue, forKey: filterEffectName)
        }
        
        var filteredImage: UIImage?
        if let output = filter?.value(forKey: kCIOutputImageKey) as? CIImage, let cgImageResult = context.createCGImage(output, from: output.extent){
            filteredImage = UIImage(cgImage: cgImageResult)
        }
        
        return filteredImage!
        
    }
    
    @IBAction func applySepia(_ sender: UIButton) {
        guard let image = imageView.image else {return}
        imageView.image = applyFilterTo(image: image, filterEffect: Filter(filterName: "CISepiaTone", filterEffectValue: 0.7, filterEffectName: kCIInputIntensityKey))
    }
    
    @IBAction func applyBlure(_ sender: UIButton) {
        guard let image = imageView.image else {return}
        imageView.image = applyFilterTo(image: image, filterEffect: Filter(filterName: "CIGaussianBlur", filterEffectValue: 0.8, filterEffectName: kCIInputRadiusKey))
    }
    
    @IBAction func applyNoir(_ sender: UIButton) {
        guard let image = imageView.image else {return}
        imageView.image = applyFilterTo(image: image, filterEffect: Filter(filterName: "CIPhotoEffectNoir", filterEffectValue: nil, filterEffectName: nil))
    }
    
    @IBAction func applyProcessing(_ sender: UIButton) {
        guard let image = imageView.image else {return}
        imageView.image = applyFilterTo(image: image, filterEffect: Filter(filterName: "CIPhotoEffectProcess", filterEffectValue: nil, filterEffectName: nil))
    }
    
    @IBAction func resetImage(_ sender: UIButton) {
        imageView.image = originalImage
    }
}

